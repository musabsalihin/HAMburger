======HAMBurger POS System======
=========Team Members===========
Name: Akmal Izudin Bin Zakaria
Student ID: SW01081787

Name: Wan Haziq Iskandar Bin Wan 
Student ID: SW01082021

Name: Mus'ab Salihin Bin Mustaffa
Student ID: SW01081837
=================================

+++	INSTRUCTIONS	+++

1. Create a java project in your IDE.
2. Copy all the content of this folder into your project folder 'src'.
3. Open App.java
4. Run the file
5. Enter username and password
	username = admin
	password = admin123
6. Open daily_entry.txt to observe the output after receipt confirmation

+++++++++++++++++++++++++++