public class App {
    public static void main(String[] args) {
        // GUI startApp = new GUI();
        GUI startApp = new GUI();
        startApp.Open();
    }
}
