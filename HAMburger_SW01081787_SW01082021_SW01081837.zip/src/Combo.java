public class Combo extends Menu {
    private Burger burger;
    private Side side;
    private Cold_Drinks drink;
    private int qty;

    
    public Combo(String name, double price)
    {
        super(name, price);
    }

    public String getType() { //tak tau cane nak buat
        return burger.getName() + " combo with " + side.getName() + " and " + drink.getName();
    }
}